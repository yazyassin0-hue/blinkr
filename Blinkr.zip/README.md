# Blinkr - Starter (Demo)
نسخة جاهزة لتشغيل تطبيق Blinkr في Bolt أو VS Code.

## تشغيل محلي (بعد فك الضغط)
1. npm install
2. npm run dev

## ملاحظات مهمة
- تم تضمين وضع **Demo** لمحاكاة Supabase/Supachat محليًا. 
- لتفعيل Supabase الحقيقي، ضع مفاتيحك في `src/lib/supabaseClient.js`.
- التطبيق يدعم العربية بشكل افتراضي ويحتوي إعدادات للإنجليزية.

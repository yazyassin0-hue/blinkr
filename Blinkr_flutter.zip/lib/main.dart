void main() { print('Blinkr skeleton'); }
